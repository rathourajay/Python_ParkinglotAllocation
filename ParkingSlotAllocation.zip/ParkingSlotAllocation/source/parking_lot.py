#!/usr/bin/python
import os, sys
import parking

class ParkingAllocation(object):

    def __init__(self):
        self.parking = parking.Parking()

    def read_file(self, given_file):
        if not os.path.exists(given_file):
            print ("Given file %s does not exist" % given_file)

        file_obj = open(given_file)
        try:
            while True:
                line = file_obj.__next__()
                if line.endswith('\n'): line = line[:-1]
                if line == '':continue
                self.execute_commands(line)
        except StopIteration:
            file_obj.close()
        except Exception as ex:
            print ("Error occured while processing file %s" % ex)

    def execute_commands(self, stdin_input):
        inputs = stdin_input.split()
        cmd = inputs[0]
        cmd_val = inputs[1:]
        if hasattr(self.parking, cmd):
            try:
                check_command = getattr(self.parking, cmd)
                check_command(*cmd_val)
            except:
                print ("Parking slot not available")
        else:
            print ("Wrong input!")


if __name__ == "__main__":
    args = sys.argv
    if len(args) == 1:
        pk_aloc = ParkingAllocation()
        try:
            while True:
                stdin_input = input("Enter command: ")
                pk_aloc.execute_commands(stdin_input)
        except Exception as ex:
            print ("Error occured while processing input %s" % ex)

    elif len(args) == 2:
        pk_aloc = ParkingAllocation()
        pk_aloc.read_file(args[1])
    else:
        print ("Please provide correct input!")
